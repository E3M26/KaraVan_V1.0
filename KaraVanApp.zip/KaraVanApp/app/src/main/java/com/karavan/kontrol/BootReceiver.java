package com.karavan.kontrol;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Telefon açılınca, izleme açık bırakıldıysa bildirim servisini yeniden başlatır. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        String a = i.getAction();
        if (!Intent.ACTION_BOOT_COMPLETED.equals(a) && !Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)) return;
        if (c.getSharedPreferences(AlertService.PREFS, Context.MODE_PRIVATE).getBoolean(AlertService.PREF_ENABLED, false))
            AlertService.start(c);
    }
}
