package com.karavan.kontrol;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.PowerManager;
import android.webkit.CookieManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashSet;
import java.util.Set;

/**
 * Arka planda KaraVan kartını izler ve yeni ikazları Android bildirimi olarak gösterir.
 *
 * Telefon KaraVan Wi-Fi'sine bağlıyken birkaç saniyede bir /api/status yoklanır.
 * Uygulamanın web görünümündeki oturum çerezi kullanılır (ayrı giriş gerekmez).
 * Android bu tür sürekli çalışan servisler için kalıcı bir bildirim göstermeyi zorunlu tutar.
 */
public class AlertService extends Service {

    public static final String ACTION_STOP = "com.karavan.kontrol.STOP";
    public static final String ACTION_MUTE = "com.karavan.kontrol.MUTE";
    public static final String ACTION_DISMISSED = "com.karavan.kontrol.DISMISSED";
    static final String PREFS = "kv_watch";
    static final String PREF_ENABLED = "enabled";

    private static final String HOST_URL = "http://192.168.4.1";
    private static final String CH_WATCH = "kv_watch";
    private static final String CH_ALERT = "kv_ikaz";     // tüm ikazlar tek kanalda, telefonun bildirim sesiyle
    private static final String[] OLD_CHANNELS = { "kv_alarm2", "kv_warn", "kv_info" };
    private static final int ID_WATCH = 1;
    private static final int ID_ALERT = 2;                // tüm ikazlar TEK bildirimde güncellenir
    private static final long POLL_MS = 4000;

    private HandlerThread thread;
    private Handler bg;
    private ConnectivityManager cm;
    private ConnectivityManager.NetworkCallback cb;
    private volatile Network wifi;
    private PowerManager.WakeLock wake;
    private WifiManager.WifiLock wifiLock;
    private NotificationManager nm;
    private SharedPreferences prefs;

    private volatile boolean alertShown = false;          // ikaz bildirimi ekranda mı (kullanıcı kaydırıp kapatabilir)
    private String lastAlert = "";                        // aynı içerik tekrar tekrar gönderilmez
    private String lastWatchText = "";
    private int failCount = 0;

    // ---------------------------------------------------------------------
    public static void start(Context c) {
        c.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(PREF_ENABLED, true).apply();
        Intent i = new Intent(c, AlertService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
        } catch (Exception ignored) { }
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        createChannels();
        goForeground("Başlatılıyor…");

        thread = new HandlerThread("kv-watch");
        thread.start();
        bg = new Handler(thread.getLooper());

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "KaraVan:watch");
        wake.setReferenceCounted(false);
        wake.acquire();
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            int mode = Build.VERSION.SDK_INT >= 29 ? WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                                                   : WifiManager.WIFI_MODE_FULL_HIGH_PERF;
            wifiLock = wm.createWifiLock(mode, "KaraVan:wifi");
            wifiLock.setReferenceCounted(false);
            wifiLock.acquire();
        } catch (Exception ignored) { wifiLock = null; }

        cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkRequest req = new NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build();
        cb = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(Network n) { wifi = n; bg.post(poll); }
            @Override public void onLost(Network n) { if (n.equals(wifi)) wifi = null; }
        };
        try { cm.registerNetworkCallback(req, cb); } catch (Exception e) { cb = null; }

        bg.post(poll);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        goForeground(lastWatchText.isEmpty() ? "Başlatılıyor…" : lastWatchText);
        String a = intent != null ? intent.getAction() : null;
        if (ACTION_STOP.equals(a)) {
            prefs.edit().putBoolean(PREF_ENABLED, false).apply();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_DISMISSED.equals(a)) { alertShown = false; return START_STICKY; }
        if (ACTION_MUTE.equals(a)) bg.post(() -> {
            boolean ok = post("/api/mute");
            if (!ok) quietAlert("KaraVan", "Susturulamadı: karta ulaşılamıyor");
        });
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (bg != null) bg.removeCallbacksAndMessages(null);
        if (thread != null) thread.quitSafely();
        if (cb != null) try { cm.unregisterNetworkCallback(cb); } catch (Exception ignored) { }
        if (wake != null && wake.isHeld()) wake.release();
        if (wifiLock != null && wifiLock.isHeld()) wifiLock.release();
        super.onDestroy();
    }

    // ---------------------------------------------------------------------
    //  Yoklama
    // ---------------------------------------------------------------------
    private final Runnable poll = new Runnable() {
        @Override public void run() {
            bg.removeCallbacks(this);
            try { check(); } catch (Exception ignored) { }
            bg.postDelayed(this, POLL_MS);
        }
    };

    private void check() {
        Network n = wifi;
        if (n == null) { setWatch("KaraVan Wi-Fi'sine bağlı değil"); return; }
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) n.openConnection(new URL(HOST_URL + "/api/status"));
            prepare(c);
            int code = c.getResponseCode();
            if (code == 401) { failCount = 0; setWatch("Giriş gerekli: uygulamayı açıp giriş yapın"); return; }
            if (code != 200) throw new Exception("http " + code);
            JSONObject s = new JSONObject(readAll(c.getInputStream()));
            failCount = 0;
            handleStatus(s);
        } catch (Exception e) {
            // Tek tük kayıplar normal (kart meşgul); art arda olursa göster
            if (++failCount >= 3) setWatch("Karta ulaşılamıyor");
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private void handleStatus(JSONObject s) {
        long bid = s.optLong("bid");
        JSONArray al = s.optJSONArray("al");
        Set<String> seen = new HashSet<>(prefs.getStringSet("seen", new HashSet<>()));
        Set<String> nowKeys = new HashSet<>();
        StringBuilder names = new StringBuilder(), lines = new StringBuilder();
        boolean isNew = false, alarm = false, allMuted = true;
        String firstKind = null;

        if (al != null) for (int i = 0; i < al.length(); i++) {
            JSONObject a = al.optJSONObject(i);
            if (a == null) continue;
            String k = a.optString("k");
            String key = bid + ":" + a.optLong("id");
            nowKeys.add(key);
            if (firstKind == null) firstKind = k;
            if (a.optInt("lv", 2) >= 2) alarm = true;
            if (a.optInt("mu") != 1) allMuted = false;
            if (names.length() > 0) { names.append(", "); lines.append("\n\n"); }
            names.append(Texts.title(k));
            lines.append("• ").append(Texts.title(k)).append(": ").append(Texts.body(k));
            if (!seen.contains(key)) { seen.add(key); isNew = true; }
        }

        if (nowKeys.isEmpty()) {
            // Hepsi bitti: aynı bildirim sessizce "sona erdi" olur
            if (alertShown) quietAlert("KaraVan", "İkazlar sona erdi");
            alertShown = false; lastAlert = "";
        } else {
            String title = nowKeys.size() == 1 ? "⚠ " + names : "⚠ " + nowKeys.size() + " ikaz: " + names;
            String text = nowKeys.size() == 1 ? Texts.body(firstKind) : lines.toString();
            showAlert(title, text, isNew, alarm, allMuted);
        }
        if (isNew) {
            // Sınırsız büyümesin: sadece şu an aktif olanları tut
            if (seen.size() > 60) seen = nowKeys;
            prefs.edit().putStringSet("seen", seen).apply();
        }
        setWatch(names.length() == 0 ? "İzleniyor · ikaz yok" : "Aktif ikaz: " + names);
    }

    // ---------------------------------------------------------------------
    //  Bildirimler
    // ---------------------------------------------------------------------
    private void createChannels() {
        if (Build.VERSION.SDK_INT < 26) return;
        for (String old : OLD_CHANNELS) try { nm.deleteNotificationChannel(old); } catch (Exception ignored) { }

        NotificationChannel w = new NotificationChannel(CH_WATCH, "Arka plan izleme", NotificationManager.IMPORTANCE_MIN);
        w.setDescription("KaraVan izlenirken görünen kalıcı bildirim");
        w.setShowBadge(false);
        nm.createNotificationChannel(w);

        // Ses ve titreşim telefonun varsayılan bildirim ayarları (uygulamaya özel ses yok)
        NotificationChannel a = new NotificationChannel(CH_ALERT, "İkazlar", NotificationManager.IMPORTANCE_HIGH);
        a.setDescription("Gaz, duman, hırsız alarmı, Webasto arızası ve sensör uyarıları");
        a.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(a);
    }

    private Notification.Builder builder(String ch) {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, ch)
                                                             : new Notification.Builder(this);
        b.setSmallIcon(R.drawable.ic_stat_karavan)
         .setColor(Color.parseColor("#FF8A3D"))
         .setContentIntent(openApp());
        return b;
    }

    private PendingIntent openApp() {
        Intent i = new Intent(this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private PendingIntent serviceAction(String action, int code) {
        Intent i = new Intent(this, AlertService.class).setAction(action);
        if (Build.VERSION.SDK_INT >= 26)
            return PendingIntent.getForegroundService(this, code, i, PendingIntent.FLAG_IMMUTABLE);
        return PendingIntent.getService(this, code, i, PendingIntent.FLAG_IMMUTABLE);
    }

    private Notification watchNotification(String text) {
        Notification.Builder b = builder(CH_WATCH)
                .setContentTitle("KaraVan izleniyor")
                .setContentText(text)
                .setOngoing(true)
                .setShowWhen(false)
                .addAction(new Notification.Action.Builder(null, "İzlemeyi durdur", serviceAction(ACTION_STOP, 1)).build());
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_MIN);
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        return b.build();
    }

    private void goForeground(String text) {
        Notification n = watchNotification(text);
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(ID_WATCH, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);
            else startForeground(ID_WATCH, n);
        } catch (Exception e) {
            stopSelf();
        }
    }

    private void setWatch(String text) {
        if (text.equals(lastWatchText)) return;
        lastWatchText = text;
        try { nm.notify(ID_WATCH, watchNotification(text)); } catch (Exception ignored) { }
    }

    /** Tek ikaz bildirimi. Yeni ikaz varsa telefonun bildirim sesiyle bir kez çalar, yoksa sessizce güncellenir. */
    private void showAlert(String title, String text, boolean sound, boolean alarm, boolean muted) {
        Notification.Builder b = builder(CH_ALERT)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setOnlyAlertOnce(!sound)
                .setOngoing(false)
                .setAutoCancel(true)
                .setShowWhen(true)
                .setCategory(alarm ? Notification.CATEGORY_ALARM : Notification.CATEGORY_STATUS)
                .setVisibility(Notification.VISIBILITY_PUBLIC);
        if (sound || !alertShown) b.setWhen(System.currentTimeMillis());
        if (Build.VERSION.SDK_INT < 26) {
            b.setPriority(Notification.PRIORITY_HIGH);
            b.setDefaults(Notification.DEFAULT_ALL);
        }
        if (alarm && !muted)
            b.addAction(new Notification.Action.Builder(null, "Kartın sesini sustur", serviceAction(ACTION_MUTE, 2)).build());
        String sig = title + "|" + text + "|" + (alarm && !muted);
        if (!sound && (!alertShown || sig.equals(lastAlert))) return;   // değişmediyse ya da kullanıcı kapattıysa dokunma
        b.setDeleteIntent(serviceAction(ACTION_DISMISSED, 3));
        try { nm.notify(ID_ALERT, b.build()); alertShown = true; lastAlert = sig; } catch (Exception ignored) { }
    }

    /** Aynı bildirim yerinde, ses çıkarmadan bilgi. */
    private void quietAlert(String title, String text) {
        Notification n = builder(CH_ALERT)
                .setContentTitle(title)
                .setContentText(text)
                .setOnlyAlertOnce(true)
                .setAutoCancel(true)
                .setShowWhen(true)
                .build();
        try { nm.notify(ID_ALERT, n); } catch (Exception ignored) { }
    }

    // ---------------------------------------------------------------------
    //  HTTP
    // ---------------------------------------------------------------------
    private void prepare(HttpURLConnection c) {
        c.setConnectTimeout(3000);
        c.setReadTimeout(4000);
        c.setUseCaches(false);
        c.setRequestProperty("User-Agent", "KaraVanApp/1.2 (bildirim servisi)");   // kart uygulamalı telefonu tanır
        try {
            String ck = CookieManager.getInstance().getCookie(HOST_URL + "/");
            if (ck != null) c.setRequestProperty("Cookie", ck);
        } catch (Exception ignored) { }
    }

    private boolean post(String path) {
        Network n = wifi;
        if (n == null) return false;
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) n.openConnection(new URL(HOST_URL + path));
            prepare(c);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            try (OutputStream o = c.getOutputStream()) { o.write(new byte[0]); }
            return c.getResponseCode() == 200;
        } catch (Exception e) {
            return false;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static String readAll(InputStream in) throws Exception {
        try (InputStream i = in) {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            byte[] buf = new byte[2048];
            int r;
            while ((r = i.read(buf)) > 0) b.write(buf, 0, r);
            return b.toString("UTF-8");
        }
    }

    // ---------------------------------------------------------------------
    static final class Texts {
        static String title(String k) {
            switch (k) {
                case "gas": return "Gaz algılandı";
                case "smoke": return "Duman algılandı";
                case "burglar": return "Hırsız alarmı";
                case "heater": return "Webasto arızası";
                case "cabsens": return "İç ortam sensörü okunamıyor";
                case "outsens": return "Webasto çıkış sensörü okunamıyor";
                default: return "İkaz: " + k;
            }
        }
        static String body(String k) {
            switch (k) {
                case "gas": return "Gaz dedektörü alarm veriyor. Tüp vanasını kapatın, havalandırın, kıvılcım çıkarabilecek şeyleri kullanmayın.";
                case "smoke": return "Duman dedektörü alarm veriyor. Karavanı hemen kontrol edin; yangın varsa dışarı çıkın ve 112'yi arayın.";
                case "burglar": return "Alarm kuruluyken içeride hareket algılandı. Tek başınıza girmeyin, gerekirse 112'yi arayın.";
                case "heater": return "Webasto otomatik kontrolü durduruldu. Webasto'yu kontrol edip uygulamadan arızayı silin.";
                case "cabsens": return "Termostat çalışamıyor; Webasto otomatik başlatılmaz.";
                case "outsens": return "Webasto'nun çalıştığı doğrulanamıyor.";
                default: return "Ayrıntılar için uygulamayı açın.";
            }
        }
    }
}
