package com.karavan.kontrol;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashSet;
import java.util.Set;

/**
 * KaraVan kontrol paneli.
 *
 * Kartın Wi-Fi erişim noktasındaki (192.168.4.1) web arayüzünü tam ekran gösterir.
 *
 * Bağlantı akışı:
 *  - Uygulama sayfa olaylarına güvenmez. Telefonun Wi-Fi ağlarında birkaç saniyede bir
 *    http://192.168.4.1/api/info yoklanır; yalnız KaraVan kartı {"title":...} ile cevap verir.
 *  - Kart bulunana kadar logolu "Bağlantı bekleniyor" ekranı görünür (telefon başka bir
 *    Wi-Fi'ye bağlıyken de). Kart bulununca uygulama o ağa bağlanır (bindProcessToNetwork)
 *    ve panel yüklenir; bekleme ekranı ancak panel gerçekten yüklenince kalkar.
 *  - Bağlantı koparsa bekleme ekranı geri gelir ve yoklama yeniden başlar.
 */
public class MainActivity extends Activity {

    private static final String HOST = "192.168.4.1";
    private static final String HOME_URL = "http://" + HOST + "/";
    private static final long PROBE_MS = 3000;          // kart aranırken yoklama aralığı
    private static final long LOAD_TIMEOUT_MS = 15000;  // kart bulundu ama panel gelmedi

    private WebView web;
    private LinearLayout waitView;
    private TextView waitTitle, waitText;
    private Button wifiBtn;
    private ConnectivityManager cm;
    private ConnectivityManager.NetworkCallback wifiCallback;
    private final Set<Network> wifiNets = new HashSet<>();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private HandlerThread probeThread;
    private Handler probe;

    private boolean connected = false;   // KaraVan kartı bulundu, panel gösteriliyor/yükleniyor
    private boolean pageShown = false;   // panel gerçekten yüklendi
    private int loadSeq = 0;             // her yüklemeye numara: eski/iptal olayları yok sayılır
    private int failedProbes = 0;

    // ---------------------------------------------------------------------
    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#101417"));

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#101417"));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);           // localStorage: kapatılan ikazlar, tercihler
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        // Sayfalar ve kart uygulamada açıldığını bu ekten anlar
        s.setUserAgentString(s.getUserAgentString() + " KaraVanApp/1.4");
        CookieManager.getInstance().setAcceptCookie(true);   // "beni hatırla"

        web.setWebChromeClient(new WebChromeClient());       // confirm() pencereleri için
        web.setWebViewClient(new WebViewClient() {
            private boolean failed = false;
            private int seqAtStart = -1;

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (HOST.equals(u.getHost())) return false;  // kartın sayfaları uygulamada
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap fav) {
                failed = false;
                seqAtStart = loadSeq;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                CookieManager.getInstance().flush();
                // Yalnız kart bulunduktan sonraki, hatasız ve güncel yükleme paneli gösterir
                if (connected && !failed && seqAtStart == loadSeq
                        && url != null && url.startsWith("http://" + HOST)) {
                    pageShown = true;
                    ui.removeCallbacks(loadTimeout);
                    hideWait();
                }
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError err) {
                if (req.isForMainFrame()) {
                    failed = true;
                    lostConnection("Panel yüklenemedi");
                }
            }
        });
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        waitView = buildWaitView();
        root.addView(waitView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        probeThread = new HandlerThread("kv-probe");
        probeThread.start();
        probe = new Handler(probeThread.getLooper());

        watchWifi();
        setupNotifications();
        probe.post(probeRun);
    }

    // ---------------------------------------------------------------------
    //  Kartı bulma
    // ---------------------------------------------------------------------
    private void watchWifi() {
        NetworkRequest req = new NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) // kartta internet yok
                .build();
        wifiCallback = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(Network n) {
                synchronized (wifiNets) { wifiNets.add(n); }
                probe.removeCallbacks(probeRun);
                probe.post(probeRun);                       // hemen dene
            }
            @Override public void onLost(Network n) {
                synchronized (wifiNets) { wifiNets.remove(n); }
                ui.post(() -> { if (connected) lostConnection("Wi-Fi bağlantısı koptu"); });
            }
        };
        try { cm.registerNetworkCallback(req, wifiCallback); } catch (Exception e) { wifiCallback = null; }
    }

    /** Arka planda: Wi-Fi ağlarında KaraVan kartını ara. Bulunana kadar tekrarlar. */
    private final Runnable probeRun = new Runnable() {
        @Override public void run() {
            probe.removeCallbacks(this);
            if (connected) return;
            Network found = null;
            Network[] nets;
            synchronized (wifiNets) { nets = wifiNets.toArray(new Network[0]); }
            for (Network n : nets) if (isKaraVan(n)) { found = n; break; }
            final Network net = found;
            ui.post(() -> onProbeResult(net));
            if (net == null) probe.postDelayed(this, PROBE_MS);
        }
    };

    /** Yalnız KaraVan kartı /api/info'ya {"title":...} cevabı verir. */
    private static boolean isKaraVan(Network n) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) n.openConnection(new URL(HOME_URL + "api/info"));
            c.setConnectTimeout(2000);
            c.setReadTimeout(2000);
            c.setUseCaches(false);
            if (c.getResponseCode() != 200) return false;
            try (InputStream in = c.getInputStream()) {
                ByteArrayOutputStream b = new ByteArrayOutputStream();
                byte[] buf = new byte[512];
                int r, total = 0;
                while ((r = in.read(buf)) > 0 && total < 4096) { b.write(buf, 0, r); total += r; }
                String body = b.toString("UTF-8").trim();
                return body.startsWith("{\"title\"");
            }
        } catch (Exception e) {
            return false;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private void onProbeResult(Network net) {
        if (connected) return;
        if (net == null) {
            failedProbes++;
            if (failedProbes >= 2) showNotFound();   // ilk denemelerde sadece "bekleniyor"
            return;
        }
        // Kart bulundu: uygulamanın trafiğini bu ağa bağla ve paneli yükle
        failedProbes = 0;
        connected = true;
        pageShown = false;
        cm.bindProcessToNetwork(net);
        waitTitle.setText("KaraVan bulundu");
        waitText.setText("Panel açılıyor…");
        wifiBtn.setVisibility(View.GONE);
        loadSeq++;
        web.loadUrl(HOME_URL);
        ui.removeCallbacks(loadTimeout);
        ui.postDelayed(loadTimeout, LOAD_TIMEOUT_MS);
    }

    private final Runnable loadTimeout = () -> { if (connected && !pageShown) lostConnection("Panel yanıt vermedi"); };

    /** Bağlantı koptu ya da panel yüklenemedi: bekleme ekranına dön, yeniden ara. */
    private void lostConnection(String why) {
        ui.removeCallbacks(loadTimeout);
        boolean wasConnected = connected;
        connected = false;
        pageShown = false;
        loadSeq++;                                   // süren yüklemenin olaylarını yok say
        try { cm.bindProcessToNetwork(null); } catch (Exception ignored) { }
        showWait("Bağlantı bekleniyor…", wasConnected
                ? why + ". KaraVan Wi-Fi ağına yeniden bağlanılınca panel kendiliğinden açılır."
                : "Telefon KaraVan Wi-Fi ağına bağlanınca panel kendiliğinden açılır.");
        probe.removeCallbacks(probeRun);
        probe.postDelayed(probeRun, 1000);
    }

    // ---------------------------------------------------------------------
    //  Bekleme ekranı (logo + durum + Wi-Fi ayarları)
    // ---------------------------------------------------------------------
    private void showWait(String title, String text) {
        waitTitle.setText(title);
        waitText.setText(text);
        waitView.animate().cancel();
        waitView.setAlpha(1f);
        waitView.setVisibility(View.VISIBLE);
    }

    private void showNotFound() {
        if (waitView.getVisibility() != View.VISIBLE) return;
        waitTitle.setText("KaraVan ağı bulunamadı");
        waitText.setText("Telefon şu an KaraVan Wi-Fi ağına bağlı değil.\n"
                + "Wi-Fi ayarlarından KaraVan-XXXX ağını seçin. Telefon \"internet yok\" "
                + "diye sorarsa bağlı kalmayı seçin.\n\nBağlantı gelince panel kendiliğinden açılır.");
        wifiBtn.setVisibility(View.VISIBLE);
    }

    private void hideWait() {
        if (waitView.getVisibility() == View.VISIBLE)
            waitView.animate().alpha(0f).setDuration(200).withEndAction(() -> waitView.setVisibility(View.GONE)).start();
    }

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private LinearLayout buildWaitView() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(28), dp(28), dp(28), dp(28));
        v.setBackgroundColor(Color.parseColor("#101417"));
        v.setClickable(true);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(112), dp(112));
        lp.bottomMargin = dp(14);
        v.addView(logo, lp);

        TextView brand = new TextView(this);
        brand.setText("KaraVan");
        brand.setTextColor(Color.parseColor("#FF8A3D"));
        brand.setTextSize(26);
        brand.setTypeface(Typeface.DEFAULT_BOLD);
        brand.setGravity(Gravity.CENTER);
        v.addView(brand);

        ProgressBar pb = new ProgressBar(this);
        pb.setIndeterminate(true);
        pb.setIndeterminateTintList(ColorStateList.valueOf(Color.parseColor("#FF8A3D")));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(34), dp(34));
        pp.topMargin = dp(24);
        v.addView(pb, pp);

        waitTitle = new TextView(this);
        waitTitle.setText("Bağlantı bekleniyor…");
        waitTitle.setTextColor(Color.parseColor("#E6ECEF"));
        waitTitle.setTextSize(18);
        waitTitle.setTypeface(Typeface.DEFAULT_BOLD);
        waitTitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tl.topMargin = dp(16);
        v.addView(waitTitle, tl);

        waitText = new TextView(this);
        waitText.setText("Telefon KaraVan Wi-Fi ağına bağlanınca panel kendiliğinden açılır.");
        waitText.setTextColor(Color.parseColor("#8B98A1"));
        waitText.setTextSize(15);
        waitText.setGravity(Gravity.CENTER);
        waitText.setLineSpacing(0, 1.2f);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tp.topMargin = dp(8);
        tp.bottomMargin = dp(20);
        v.addView(waitText, tp);

        wifiBtn = makeButton("Wi-Fi ayarları", true);
        wifiBtn.setOnClickListener(b -> {
            try { startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)); } catch (Exception ignored) { }
        });
        wifiBtn.setVisibility(View.GONE);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(240), dp(52));
        bp.topMargin = dp(6);
        v.addView(wifiBtn, bp);
        return v;
    }

    private Button makeButton(String text, boolean primary) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(Color.parseColor(primary ? "#1A0D04" : "#E6ECEF"));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(12));
        bg.setColor(Color.parseColor(primary ? "#FF8A3D" : "#1F292F"));
        if (!primary) bg.setStroke(dp(1), Color.parseColor("#283239"));
        b.setBackground(bg);
        return b;
    }

    // ---------------------------------------------------------------------
    //  Arka plan ikaz bildirimleri
    // ---------------------------------------------------------------------
    private static final int REQ_NOTIF = 7;

    /** Bildirim izni (Android 13+) istenir, izleme servisi başlatılır. */
    private void setupNotifications() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{ android.Manifest.permission.POST_NOTIFICATIONS }, REQ_NOTIF);
        } else {
            startWatch();
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_NOTIF) startWatch();   // izin verilmese de servis çalışır, bildirim görünmez
    }

    private void startWatch() {
        AlertService.start(this);
        askBatteryOnce();
    }

    /** Pil tasarrufu servisi uyutmasın diye bir kez muafiyet ister. */
    @SuppressLint("BatteryLife")
    private void askBatteryOnce() {
        SharedPreferences p = getSharedPreferences(AlertService.PREFS, MODE_PRIVATE);
        if (p.getBoolean("askedBattery", false)) return;
        p.edit().putBoolean("askedBattery", true).apply();
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm.isIgnoringBatteryOptimizations(getPackageName())) return;
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception ignored) { }
    }

    // ---------------------------------------------------------------------
    @Override
    public void onBackPressed() {
        if (pageShown && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override protected void onResume() {
        super.onResume();
        web.onResume();
        if (!connected) { probe.removeCallbacks(probeRun); probe.post(probeRun); }   // Wi-Fi ayarlarından dönünce hemen dene
    }

    @Override protected void onPause() {
        CookieManager.getInstance().flush();
        web.onPause();
        super.onPause();
    }

    @Override protected void onDestroy() {
        ui.removeCallbacksAndMessages(null);
        if (probe != null) probe.removeCallbacksAndMessages(null);
        if (probeThread != null) probeThread.quitSafely();
        if (wifiCallback != null) {
            try { cm.unregisterNetworkCallback(wifiCallback); } catch (Exception ignored) { }
        }
        try { cm.bindProcessToNetwork(null); } catch (Exception ignored) { }
        web.destroy();
        super.onDestroy();
    }
}
