package com.karavan.kontrol;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * KaraVan kontrol paneli.
 *
 * Kartın Wi-Fi erişim noktasındaki (192.168.4.1) web arayüzünü tam ekran gösterir.
 * Kartın ağında internet olmadığı için Android istekleri mobil veriye yönlendirebilir;
 * bu yüzden uygulama kendini Wi-Fi ağına bağlar (bindProcessToNetwork).
 */
public class MainActivity extends Activity {

    private static final String HOST = "192.168.4.1";
    private static final String HOME_URL = "http://" + HOST + "/";
    private static final long RETRY_MS = 5000;

    private WebView web;
    private LinearLayout errorView;
    private TextView errorText;
    private ConnectivityManager cm;
    private ConnectivityManager.NetworkCallback wifiCallback;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean loadedOnce = false;
    private boolean errorShown = false;

    private final Runnable retry = new Runnable() {
        @Override public void run() {
            if (errorShown) {
                web.loadUrl(HOME_URL);
                handler.postDelayed(this, RETRY_MS);
            }
        }
    };

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#101417"));

        // --- Web görünümü ---
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#101417"));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);           // localStorage: kapatılan ikazlar, tercihler
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        // Sayfalar uygulamada açıldığını bu ekten anlar ("Chrome'da aç" kutusunu göstermez)
        s.setUserAgentString(s.getUserAgentString() + " KaraVanApp/1.0");

        CookieManager.getInstance().setAcceptCookie(true);   // "beni hatırla"

        web.setWebChromeClient(new WebChromeClient());       // confirm() pencereleri için
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (HOST.equals(u.getHost())) return false;  // kartın sayfaları uygulamada
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (url != null && url.startsWith("http://" + HOST)) {
                    loadedOnce = true;
                    if (errorShown && !pageFailed) hideError();
                }
                pageFailed = false;
                CookieManager.getInstance().flush();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError err) {
                if (req.isForMainFrame()) {
                    pageFailed = true;
                    showError();
                }
            }
        });

        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // --- Bağlantı yok ekranı ---
        errorView = buildErrorView();
        errorView.setVisibility(View.GONE);
        root.addView(errorView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        setContentView(root);

        cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        watchWifi();

        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else {
            // Wi-Fi bağlaması birkaç yüz ms sürebilir; kısa bekleyip yükle
            handler.postDelayed(() -> { if (!loadedOnce) web.loadUrl(HOME_URL); }, 600);
        }
    }

    private boolean pageFailed = false;

    /** Wi-Fi ağını izle; bağlanınca uygulamanın tüm trafiğini Wi-Fi'ye yönlendir. */
    private void watchWifi() {
        NetworkRequest req = new NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) // kartta internet yok
                .build();
        wifiCallback = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(Network network) {
                cm.bindProcessToNetwork(network);
                handler.post(() -> {
                    if (!loadedOnce || errorShown) web.loadUrl(HOME_URL);
                });
            }
            @Override public void onLost(Network network) {
                cm.bindProcessToNetwork(null);
                handler.post(() -> showError());
            }
        };
        try {
            cm.registerNetworkCallback(req, wifiCallback);
        } catch (Exception e) {
            wifiCallback = null;   // izin/cihaz sorunu: bağlamadan devam et
        }
    }

    private void showError() {
        if (!errorShown) {
            errorShown = true;
            errorView.setVisibility(View.VISIBLE);
            handler.removeCallbacks(retry);
            handler.postDelayed(retry, RETRY_MS);
        }
    }

    private void hideError() {
        errorShown = false;
        errorView.setVisibility(View.GONE);
        handler.removeCallbacks(retry);
    }

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private LinearLayout buildErrorView() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(28), dp(28), dp(28), dp(28));
        v.setBackgroundColor(Color.parseColor("#101417"));
        v.setClickable(true);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(96), dp(96));
        lp.bottomMargin = dp(20);
        v.addView(logo, lp);

        TextView title = new TextView(this);
        title.setText("KaraVan'a bağlanılamıyor");
        title.setTextColor(Color.parseColor("#E6ECEF"));
        title.setTextSize(20);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        v.addView(title);

        errorText = new TextView(this);
        errorText.setText("Telefonun KaraVan Wi-Fi ağına bağlı olduğundan emin olun. "
                + "Telefon \"internet erişimi yok\" diye sorarsa bağlı kalmayı seçin.\n\n"
                + "Bağlantı gelince sayfa kendiliğinden açılır.");
        errorText.setTextColor(Color.parseColor("#8B98A1"));
        errorText.setTextSize(15);
        errorText.setGravity(Gravity.CENTER);
        errorText.setLineSpacing(0, 1.2f);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tp.topMargin = dp(10);
        tp.bottomMargin = dp(24);
        v.addView(errorText, tp);

        Button wifi = makeButton("Wi-Fi ayarları", true);
        wifi.setOnClickListener(b -> {
            try { startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)); } catch (Exception ignored) { }
        });
        v.addView(wifi, buttonParams());

        Button again = makeButton("Tekrar dene", false);
        again.setOnClickListener(b -> web.loadUrl(HOME_URL));
        v.addView(again, buttonParams());
        return v;
    }

    private Button makeButton(String text, boolean primary) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(Color.parseColor(primary ? "#1A0D04" : "#E6ECEF"));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(12));
        bg.setColor(Color.parseColor(primary ? "#FF8A3D" : "#1F292F"));
        if (!primary) bg.setStroke(dp(1), Color.parseColor("#283239"));
        b.setBackground(bg);
        return b;
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(240), dp(52));
        p.topMargin = dp(10);
        return p;
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack() && !errorShown) web.goBack();
        else super.onBackPressed();
    }

    @Override protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override protected void onPause() {
        CookieManager.getInstance().flush();
        web.onPause();
        super.onPause();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (wifiCallback != null) {
            try { cm.unregisterNetworkCallback(wifiCallback); } catch (Exception ignored) { }
        }
        cm.bindProcessToNetwork(null);
        web.destroy();
        super.onDestroy();
    }
}
