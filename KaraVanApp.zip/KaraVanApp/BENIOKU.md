# KaraVan Android uygulaması

Kartın web arayüzünü (http://192.168.4.1) tam ekran gösteren küçük bir Android uygulaması.
Ek kütüphane kullanmaz; Android'in kendi WebView'i ile çalışır. Android 7.0 ve üstü.

## Chrome kısayolundan farkı

- Telefon KaraVan Wi-Fi'sinde internet olmadığı için istekleri mobil veriye gönderebilir.
  Uygulama kendini Wi-Fi ağına bağlar, sayfa her zaman karttan gelir.
- Wi-Fi bağlı değilse "KaraVan'a bağlanılamıyor" ekranı çıkar (Wi-Fi ayarları / Tekrar dene).
  Bağlantı gelince sayfa kendiliğinden açılır.
- "Beni hatırla" çerezi kalıcıdır, uygulama kapanıp açılsa da giriş istemez.
- Ana ekranda kendi simgesiyle durur, Chrome rozeti olmaz.

## APK'yı derleme: yol 1, GitHub (kurulum gerektirmez, tarayıcıdan)

1. github.com'da ücretsiz hesap açın (varsa giriş yapın).
2. Sağ üstte **+ > New repository**. Ad: `KaraVanApp`, **Private** seçin, **Create repository**.
3. Açılan sayfada **uploading an existing file** bağlantısına tıklayın.
4. Bilgisayarda `KaraVanApp` klasörünün **içine** girin, içindeki her şeyi seçin (Ctrl+A)
   ve tarayıcıdaki yükleme alanına sürükleyin. (`.github` klasörü de gitmeli.)
5. Aşağıda **Commit changes**'e basın.
6. Üstteki **Actions** sekmesine geçin. "KaraVan APK derle" çalışmaya başlar (3-5 dk).
   Başlamadıysa soldan "KaraVan APK derle"yi seçip **Run workflow**'a basın.
7. Yeşil ✓ çıkınca çalışmaya tıklayın; en altta **Artifacts > KaraVan-apk**'yı indirin.
   İnen zip'in içinde `KaraVan.apk` var.

Kırmızı ✗ çıkarsa çalışmaya tıklayıp "APK derle" adımındaki hatayı kopyalayın.

## APK'yı derleme: yol 2, Android Studio

1. Bilgisayara **Android Studio** kurun (developer.android.com/studio).
2. Android Studio > **Open** > bu `KaraVanApp` klasörünü seçin.
3. İlk açılışta Gradle ve Android SDK'yı kendisi indirir (birkaç dakika). "Upgrade" önerirse kabul edebilirsiniz.
4. Menüden **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
5. Bitince sağ altta **locate** bağlantısı çıkar. Dosya:
   `app/build/outputs/apk/debug/app-debug.apk`

## Telefona yükleme

- **USB ile:** Telefonda Geliştirici seçenekleri > USB hata ayıklama açık, telefonu bağlayın,
  Android Studio'da yeşil ▶ (Run) düğmesine basın. Uygulama yüklenip açılır.
- **Dosya ile:** `app-debug.apk` dosyasını telefona kopyalayın (USB, e-posta, Drive),
  dosyaya dokunun. "Bilinmeyen kaynaklardan yükleme" izni sorarsa izin verin.

## Kullanım

1. Telefonu KaraVan Wi-Fi ağına bağlayın. "İnternet yok, bağlı kalınsın mı?" sorusuna **Evet**.
2. KaraVan uygulamasını açın, "Beni hatırla" ile bir kez giriş yapın.

## Ayarlar

- Kart adresi `MainActivity.java` içinde `HOST = "192.168.4.1"`.
- Uygulama adı `app/src/main/res/values/strings.xml`.
- Simgeler `app/src/main/res/mipmap-*` klasörlerinde (KaraVan rozetinden üretildi).

## v1.1 — Arka planda ikaz bildirimi
- Uygulama açılınca "KaraVan izleniyor" servisi başlar; telefon KaraVan Wi-Fi'sine bağlıyken 4 sn'de bir kartı yoklar.
- Yeni ikazda (gaz, duman, hırsız, Webasto arızası) alarm sesli, titreşimli bildirim; "Sesi sustur" düğmesi kartın sesini susturur.
- Uygulama kapalıyken ve telefon yeniden başladıktan sonra da çalışır. Durdurmak için kalıcı bildirimdeki "İzlemeyi durdur".
- İlk açılışta bildirim izni ve pil tasarrufu muafiyeti istenir; ikisine de izin verin.

## v1.2
- Tüm ikazlar tek bir bildirimde toplanır; yeni ikaz gelince aynı bildirim güncellenir. Ses yalnız yeni ikazda bir kez çalar.
- Ses ve titreşim telefonun kendi bildirim ayarlarıdır (uygulamaya özel ses yok). Ayarlar > Uygulamalar > KaraVan > Bildirimler > "İkazlar" kanalından değiştirilebilir.
- Kart, uygulama kullanan telefonu tanır; o telefon Wi-Fi'ye bağlanınca giriş sayfası kendiliğinden açılmaz.

## v1.3
- Açılışta panel gelene kadar logo ve "Bağlantı bekleniyor" ekranı; 12 sn'de bağlanamazsa Wi-Fi ayarları / Tekrar dene ekranı.

## v1.4
- Bağlantı akışı yeniden yazıldı: uygulama birkaç saniyede bir 192.168.4.1/api/info'yu yoklar; yalnız KaraVan kartı bulununca paneli açar. Telefon başka bir Wi-Fi'ye bağlıyken de logolu bekleme ekranı ("KaraVan ağı bulunamadı" + Wi-Fi ayarları) görünür, boş ekran kalmaz. Bağlantı koparsa bekleme ekranına dönülür.
